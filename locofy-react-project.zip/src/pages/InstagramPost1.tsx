import { FunctionComponent } from "react";

const InstagramPost1: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-100 w-full h-[1080px] overflow-hidden text-left text-mini text-gray-200 font-lato">
      <div className="absolute top-[152px] left-[11px] w-[896.73px] h-[644px]">
        <img
          className="absolute top-[0px] left-[0px] w-[896.73px] h-[644px] object-cover"
          alt=""
          src="/pngtransparentmacbookairmacbookprolaptopmacbooktemplateelectronicscomputerremovebgpreview-1@2x.png"
        />
        <img
          className="absolute top-[22.51px] left-[114.2px] w-[671.67px] h-[425.84px] object-cover"
          alt=""
          src="/macbook-pro-16---1-1@2x.png"
        />
      </div>
      <div className="absolute top-[533px] left-[499px] w-[569px] h-[394px]">
        <img
          className="absolute top-[0px] left-[0px] w-[569px] h-[394px] object-cover"
          alt=""
          src="/pngtransparentmacbookairmacbookprolaptopmacbooktemplateelectronicscomputerremovebgpreview-2@2x.png"
        />
        <img
          className="absolute top-[11px] left-[80px] w-[410px] h-[265px] object-cover"
          alt=""
          src="/macbook-pro-16---2-1@2x.png"
        />
      </div>
      <div className="absolute top-[18px] left-[8px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[8px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[558px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[558px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[118px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[118px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[668px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[668px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[228px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[228px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[778px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[778px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[338px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[338px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[888px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[888px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[448px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[448px]">@ux.evelyn</div>
      <div className="absolute top-[18px] left-[998px]">@ux.evelyn</div>
      <div className="absolute top-[1043px] left-[998px]">@ux.evelyn</div>
    </div>
  );
};

export default InstagramPost1;
