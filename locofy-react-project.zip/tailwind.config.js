/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        gray: {
          "100": "#01000f",
          "200": "rgba(255, 255, 255, 0.3)",
        },
      },
      spacing: {},
      fontFamily: {
        lato: "Lato",
      },
    },
    fontSize: {
      mini: "15px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
